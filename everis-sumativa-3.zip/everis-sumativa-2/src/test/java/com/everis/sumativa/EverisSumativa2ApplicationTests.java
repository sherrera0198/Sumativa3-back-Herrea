package com.everis.sumativa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EverisSumativa2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
