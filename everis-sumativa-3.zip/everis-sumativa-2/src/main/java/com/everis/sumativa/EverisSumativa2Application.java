package com.everis.sumativa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EverisSumativa2Application {

	public static void main(String[] args) {
		SpringApplication.run(EverisSumativa2Application.class, args);
	}

}
